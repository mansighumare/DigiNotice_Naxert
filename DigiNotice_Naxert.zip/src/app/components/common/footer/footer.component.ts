import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: 'footer.template.html'
})
export class FooterComponent { }
