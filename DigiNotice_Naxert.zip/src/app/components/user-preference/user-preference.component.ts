import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-preference',
  templateUrl: './user-preference.component.html',
  styleUrls: ['./user-preference.component.scss']
})
export class UserPreferenceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
