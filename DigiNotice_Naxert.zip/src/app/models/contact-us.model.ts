export class ContactUsModel {
    id: 0;
    name: string;
    email: string;
    phone: string;
    contactBy: number;
    contactMeType: string = "email"
    subject: string;
    status: true;
    message: string;
    userId:string;
}