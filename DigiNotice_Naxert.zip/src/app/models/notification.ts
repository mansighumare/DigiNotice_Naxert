
export class NotificationModel {
    notificationtext:string="";
}
export class NotificationList{
    notificationtext:string="";
    isActive:boolean;
    CreatedDate:Date;
}